命名规则:
  openvpn 配置文件目录: vpn-{uuid}   根目录可以: /var/lib/syscxp/vpndata/
  netns: vpn-{uuid} 做ns名 例如：vpn-345689iueywhjdsk23ldj21jdls
  veth: vpn-i-{vlan} vpn-o-{vlan} vpn-i-100 vpn-o-100
  bridge: vpn-br-{vlan} vpn-br-100
  openvpn-tun: vpn-tun-{port}  例如：vpn-tun-7654
  测试


  note:
    由于启动openvpn的时候是通过: openvpn /var/lib/syscxp/vpndata/vpn-{uuid}/server.conf 启动
    所以关闭openvpn的时候，也是通过启动特征(uuid在配置文件目录)关闭进程的


vpn agent web server 端口：7078