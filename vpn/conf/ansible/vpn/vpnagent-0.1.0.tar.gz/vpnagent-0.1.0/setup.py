from setuptools import setup, find_packages
import sys, os

version = '0.1.0'

setup(name='vpnagent',
      version=version,
      description="Syscxp VPN agent REST service",
      long_description="""\
Syscxp VPN agent REST service""",
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='syscxp kvm python agent REST',
      author='',
      author_email='',
      url='http://syscxp.org',
      license='Apache License 2',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=True,
      install_requires=[
            "pexpect"
          # -*- Extra requirements: -*-
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
