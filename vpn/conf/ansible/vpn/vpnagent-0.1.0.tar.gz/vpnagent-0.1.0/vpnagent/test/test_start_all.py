#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import start_all_plugin

def main(UUID, VLANID, VPN_SERVICE_PORT, DDN_PORT, SPEED):

    start_ = start_all_plugin.StartAll(UUID, VLANID, VPN_SERVICE_PORT, DDN_PORT, SPEED)

    res = start_.start()
    if res:
        print("VPN start success!")
    else:
        print("VPN start faild!")

    print res

if __name__ == '__main__':
    vpnuuid = "ddd123456"
    vpnvlanid = "1520"
    vpnport = "31195"
    ddnport = "enp1s0f1"
    speed = "5000"
    main(vpnuuid, vpnvlanid, vpnport, ddnport, speed)
