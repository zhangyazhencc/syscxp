#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import conf_plugin



def main(uuid, hostip, vpn_port):

    vpn_conf = conf_plugin.VpnConf(uuid, hostip, vpn_port)
    vpn_conf.create_conf('server')
    vpn_conf.create_conf('client')




if __name__ == "__main__":
    uuid = 'ccc123456'
    hostip = '192.168.211.201'
    vpn_port = '31194'
    main(uuid, hostip, vpn_port)