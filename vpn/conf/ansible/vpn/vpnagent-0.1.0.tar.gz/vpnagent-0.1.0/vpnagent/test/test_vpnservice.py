#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import vpn_service_plugin

def main(uuid, vlanid, vport, status):
    vpn_service = vpn_service_plugin.VpnService(uuid, vlanid, vport)
    if status == "start":
        vpn_service.vpn_up_down("start")
        res = vpn_service.vpn_status()
    if status == "stop":
        vpn_service.vpn_up_down("stop")
        res = vpn_service.vpn_status()
    if status == "status":
        res = vpn_service.vpn_status()
    if res:
        print("VPN service up!")
    else:
        print("VPN service down!")


if __name__ == '__main__':
    uuid = "ddd123456"
    vlanid = "1520"
    vport = "31195"
    status = "start"
    main(uuid,  vlanid, vport, status)

