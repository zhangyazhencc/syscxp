#coding:utf-8

from vpnagent.plugins import vpn_plugin
from vpnagent.plugins import settings
from vpnagent.plugins import vpn_service_plugin
from vpnagent.plugins import vinterface_plugin
from vpnagent.plugins.conf_plugin import VpnConf
from syscxplib.utils import plugin
from syscxplib.utils import http
from syscxplib.utils import log
from syscxplib.utils import jsonobject
from syscxplib.utils import daemon
from syscxplib.utils import linux
from syscxplib.utils import shell
import os.path
import traceback
import pprint
import functools
import requests
import threading
import subprocess
import time
import os
import ConfigParser

logger = log.get_logger(__name__)
SEND_COMMAND_URL = 'SEND_COMMAND_URL'
HOST_UUID = 'HOST_UUID'



def create_cert(UUID):
    cert = vpn_plugin.VpnPlugin()
    cert.init_cert(UUID)

def create_conf(SERVICE_NAME, SERVER_CONF, CLIENT_CONF):
    server_conf_name = "/etc/openvpn/{}.conf".format(SERVICE_NAME)
    client_conf_name = "/tmp/client.conf"
    vpnconf = VpnConf()
    vpnconf.create_conf_file(SERVER_CONF, server_conf_name)
    vpnconf.create_conf_file(CLIENT_CONF, client_conf_name)

def star_vpn_service(SERVICE_NAME):
    vpn_service_plugin.start_vpn(SERVICE_NAME)

def conf_vport(BR_NAME, VPORT_NAME, VPN_VPORT_NAME, DDN_PORT, VLANID):
    vport = vinterface_plugin.Vinterface()
    vport.create_br(BR_NAME)
    vport.create_vlan_vport(DDN_PORT, VLANID)
    vport.add_vport_to_br(BR_NAME, VPORT_NAME)
    vport.add_vport_to_br(BR_NAME, VPN_VPORT_NAME)

if __name__  == "__main__":
    create_cert(settings.UUID)
    create_conf(settings.SERVICE_NAME, settings.SERVER_CONF, settings.CLIENT_CONF)
    print "Start vpn service ..."
    star_vpn_service(settings.SERVICE_NAME)
    conf_vport(settings.BR_NAME, settings.VPORT_NAME, settings.VPN_VPORT_NAME, settings.DDN_PORT, settings.VLANID)