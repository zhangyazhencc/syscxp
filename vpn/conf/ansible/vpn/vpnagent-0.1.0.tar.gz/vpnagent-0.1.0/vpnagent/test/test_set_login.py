#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import login_info_plugin

def main(uuid, username, passwd):
    setinfo = login_info_plugin.LoginInfo(uuid, username, passwd)

    res = setinfo.set_login_info()
    if res:
        print("Set success")
    else:
        print("Set faild")

if __name__ == '__main__':
    uuid = "aaa123456"
    username = "user001"
    passwd = "123456"
    main(uuid, username, passwd)
