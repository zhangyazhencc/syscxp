#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import set_login_info

def main(uuid, username, passwd):
    setinfo = set_login_info.LoginInfo(uuid, username, passwd)

    res = setinfo.set_info()
    if res:
        print("Set success")
    else:
        print("Set faild")

if __name__ == '__main__':
    uuid = "aaa123456"
    username = "user001"
    passwd = "123456"
    main(uuid, username, passwd)
