#!/usr/bin/env python
#coding:utf-8

c vinterface_plugin

def main(vlanid, ddn_port, vpn_service_port):
    v_interface = vinterface_plugin.Vinterface(vlanid, ddn_port, vpn_service_port)
    v_interface.del_br_vport()



if __name__ == "__main__":
    vlanid = "1520"
    ddn_port = "enp1s0f1"
    vpn_service_port = "31195"
    main(vlanid, ddn_port, vpn_service_port)


