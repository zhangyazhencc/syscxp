#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import rate_limiting_plugin

def main(vpn_service_port, speed):
    net_rate_limiting = rate_limiting_plugin.RateLimiting(vpn_service_port, speed)
    net_rate_limiting.clean_rate_limiting()
    res = net_rate_limiting.check_rate_limiting()
    if res:
        print("limit exist")
    else:
        print("limit not exist")

if __name__ == "__main__":
    vpn_service_port = "31195"
    speed = "5000"
    main(vpn_service_port, speed)

