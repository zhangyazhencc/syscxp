#!/usr/bin/env python
#coding:utf-8

from  vpnagent.plugins import client_conf_plugin

def main(uuid):
    clientinfo = client_conf_plugin.ClientInfo(uuid)
    client_dist = clientinfo.clinet_info()
    return client_dist

if __name__ == '__main__':
    uuid = 'aaa123456'
    res = main(uuid)
    for k,v in res.items():
        print k
        print v