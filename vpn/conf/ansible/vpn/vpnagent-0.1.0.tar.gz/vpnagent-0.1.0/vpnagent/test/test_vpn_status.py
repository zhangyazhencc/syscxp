#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import vpn_status_plugin

def main(uuid):
    vpnstatus = vpn_status_plugin.VpnStatus(uuid)
    res = vpnstatus.vpn_status()
    return res

if __name__ == '__main__':
    uuid = 'aaa123456'
    res = main(uuid)
    if res:
        print "vpn up!"
    else:
        print "vpn down!"
