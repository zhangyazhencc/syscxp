#!/usr/bin/env python

from vpnagent.plugins import cert_plugin
import time

def main():
    vpn_cert = cert_plugin.VpnCert()
    res = vpn_cert.create_vpn_cert()
    return res

if __name__ == '__main__':
    uuid = 'ccc123456'
    res = main()
    print res