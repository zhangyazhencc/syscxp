#!/usr/bin/env python

from vpnagent.plugins import cert_plugin
import time

def main(uuid):
    vpn_cert = cert_plugin.VpnCert(uuid)
    vpn_cert.build_ca()
    vpn_cert.build_dh()
    vpn_cert.build_key('server')
    vpn_cert.build_key('client')
    vpn_cert.copy_cert(uuid)


if __name__ == '__main__':
    uuid = 'aaa123456'
    main(uuid)