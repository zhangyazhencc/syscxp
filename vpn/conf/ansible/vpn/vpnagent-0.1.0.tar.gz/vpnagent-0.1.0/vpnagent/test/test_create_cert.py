#!/usr/bin/env python

from vpnagent.plugins import cert_plugin
import time

def main(uuid):
    vpn_cert = cert_plugin.VpnCert(uuid)
    vpn_cert.create_vpn_cert()


if __name__ == '__main__':
    uuid = 'ccc123456'
    main(uuid)