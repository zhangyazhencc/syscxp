#!/usr/bin/env python
#coding:utf-8
from syscxplib.utils import log
import subprocess
import sys
import os

logger = log.get_logger(__name__)

class Vinterface(object):

    def __init__(self, VLANID, DDN_PORT, VPN_SERVICE_PORT):

        self.VLANID = VLANID
        self.DDN_PORT = DDN_PORT
        self.BR_NAME = "vpn-br-{}".format(VLANID)
        self.VLAN_VPORT = "{}.{}".format(DDN_PORT, VLANID)
        self.VPN_VPORT = "tap-vpn-{}".format(VPN_SERVICE_PORT)

    def exec_command(self, cmd):
        subprocess.call(cmd, shell=True, stdout=sys.stdout, stderr=sys.stderr)

    def create_br(self):
        logger.info("create linux bridge")
        cmd = "brctl addbr {} && ifconfig {} up".format(self.BR_NAME, self.BR_NAME)
        self.exec_command(cmd)

    def del_br(self):
        logger.info("delete linux bridge")
        cmd = "ifconfig {} down && brctl delbr {} ".format(self.BR_NAME, self.BR_NAME)
        self.exec_command(cmd)

    def vlan_vport_to_br(self):
        logger.info("create %s.%s and add to %s" % (self.DDN_PORT, self.VLANID, self.BR_NAME))
        cmd = "vconfig add {} {} && brctl addif {} {} && " \
              "ifconfig {} up".format(self.DDN_PORT, self.VLANID, self.BR_NAME,
                                      self.VLAN_VPORT, self.VLAN_VPORT)
        self.exec_command(cmd)

    def del_vlan_vport(self):
        logger.info("delete %s.%s " % (self.DDN_PORT, self.VLANID))
        cmd = "vconfig rem {}.{}".format(self.DDN_PORT, self.VLANID)
        self.exec_command(cmd)

    def vpn_vport_to_br(self):
        logger.info("add port %s to bridge %s" % ( self.VPN_VPORT, self.BR_NAME))
        cmd = "brctl addif {} {} && ifconfig {} up".format(self.BR_NAME,
                                                           self.VPN_VPORT, self.VPN_VPORT)
        self.exec_command(cmd)

    def del_vpn_vport(self):
        logger.info("delete port %s from bridge %s" % (self.VPN_VPORT, self.BR_NAME))
        cmd = "brctl delif {} {} ".format(self.BR_NAME, self.VPN_VPORT)

        self.exec_command(cmd)

    def check_br_vport(self):
        ''' 检查端口是否加入桥 '''
        cmd = "brctl show {} |egrep  '{}|{}'".format(self.BR_NAME,
                                                     self.VLAN_VPORT, self.VPN_VPORT)
        res = os.popen(cmd).read().strip().split()
        if self.VLAN_VPORT in res and self.VPN_VPORT in res:
            return True
        else:
            return False

    def add_br_vport(self):
        self.create_br()
        self.vlan_vport_to_br()
        self.vpn_vport_to_br()
        return self.check_br_vport()

    def del_br_vport(self):
        self.del_vpn_vport()
        self.del_vlan_vport()
        self.del_br()
        return self.check_br_vport()

