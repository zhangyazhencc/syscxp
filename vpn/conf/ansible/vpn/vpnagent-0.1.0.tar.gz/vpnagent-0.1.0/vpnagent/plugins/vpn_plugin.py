# coding:utf-8

from syscxplib.utils import jsonobject
from syscxplib.utils import http
from syscxplib.utils import lock
from syscxplib.utils import log
from syscxplib.utils import shell
from syscxplib.utils import sizeunit
from syscxplib.utils import linux
from syscxplib.utils import thread
from syscxplib.utils.bash import *
from syscxplib.utils.report import Report
from vpnagent import vpnagent
from vpnagent.plugins import cert_plugin
from vpnagent.plugins import conf_plugin
from vpnagent.plugins import vpn_service_plugin
from vpnagent.plugins import vinterface_plugin
from vpnagent.plugins import rate_limiting_plugin
from vpnagent.plugins import destroy_vpn_plugin
from vpnagent.plugins import start_all_plugin
from vpnagent.plugins import client_conf_plugin
from vpnagent.plugins import login_info_plugin

import os.path
import time
import re
import threading


class VpnStatusResponse(vpnagent.AgentResponse):
    def __init__(self):
        super(VpnStatusResponse, self).__init__()
        self.vpnStatus = None
        self.massage = None


class VpnCertResponse(vpnagent.AgentResponse):
    def __init__(self):
        super(VpnCertResponse, self).__init__()
        self.ca_crt = None
        self.client_crt = None
        self.client_key = None
        self.client_conf = None


logger = log.get_logger(__name__)


class VpnPlugin(vpnagent.VpnAgent):
    '''
    classdocs
    '''

    CERT_PATH = '/vpn/create_cert'
    CONF_PATH = '/vpn/conf_vpn'
    LIMIT_PATH = '/vpn/rate_limiting'
    VPORT_PATH = '/vpn/vport'
    SERVICE_PATH = '/vpn/vpn_service'
    START_PATH = '/vpn/start_all'
    DESTROY_PATH = '/vpn/destroy_vpn'
    CLIENT_PATH = '/vpn/client_info'
    LOGIN_PATH = '/vpn/login_info'
    VPN_PATH = '/vpn/init_vpn'

    @vpnagent.replyerror
    def create_cert(self, req):
        logger.info("start create credentials")
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        vpn_cert = cert_plugin.VpnCert(vpn_uuid)
        res = vpn_cert.create_vpn_cert()
        rsp = VpnStatusResponse()
        if res:
            logger.info("Cert create successful")
            rsp.massage = "Cert create successful"
        else:
            logger.error("Cert create failed")
            raise Exception("Cert create failed")
        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def conf_vpn(self, req):
        logger.info("start configure vpn files")
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        host_ip = cmd.hostip
        vpn_service_port = cmd.vpnport
        vpn_conf = conf_plugin.VpnConf(vpn_uuid, host_ip, vpn_service_port)
        res = vpn_conf.create_conf()
        rsp = VpnStatusResponse()
        if res:
            logger.info("Vpn conf create successful")
            rsp.massage = "Vpn conf create successful"
        else:
            logger.error("Vpn conf create failed")
            raise Exception("Vpn conf create failed")
        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def vpn_service(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        vpn_vlanid = cmd.vpnvlanid
        vpn_service_port = cmd.vpnport
        vpn_exec_cmd = cmd.command

        vpn_service = vpn_service_plugin.VpnService(vpn_uuid,
                                                    vpn_vlanid, vpn_service_port)
        if vpn_exec_cmd == "start":
            res = vpn_service.vpn_up_down("start")

        if vpn_exec_cmd == "stop":
            res = vpn_service.vpn_up_down("stop")

        if vpn_exec_cmd == "status":
            res = vpn_service.vpn_status()

        rsp = VpnStatusResponse()
        if res:
            rsp.vpnStatus = "UP"
            rsp.massage = "VPN service up!"
        else:
            rsp.vpnStatus = "DOWN"
            rsp.massage = "VPN service down!"

        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def vpn_vport(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_vlanid = cmd.vpnvlanid
        ddn_port = cmd.ddnport
        vpn_service_port = cmd.vpnport
        exec_cmd = cmd.command

        v_interface = vinterface_plugin.Vinterface(vpn_vlanid,
                                                   ddn_port, vpn_service_port)
        rsp = VpnStatusResponse()
        if exec_cmd == "add":
            res = v_interface.add_br_vport()

            if res:
                rsp.massage = "Vport add successful"
            else:
                raise Exception("Vport add failed")
        if exec_cmd == "del":
            res = v_interface.del_br_vport()

            if not res:
                rsp.massage = "Vport del successful"
            else:
                raise Exception("Vport del failed")

        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def rate_limiting(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_service_port = cmd.vpnport
        speed = cmd.speed
        exec_cmd = cmd.command

        net_rate_limiting = rate_limiting_plugin.RateLimiting(vpn_service_port, speed)
        if exec_cmd == "set":
            res = net_rate_limiting.set_rate_limiting()

        if exec_cmd == "clean":
            res = net_rate_limiting.clean_rate_limiting()

        rsp = VpnStatusResponse()
        if res:
            rsp.massage = "Rate-limiting exist"
        else:
            raise Exception("Rate-limiting not exist")

        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def start_all(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        vpn_vlanid = cmd.vpnvlanid
        vpn_service_port = cmd.vpnport
        ddn_port = cmd.ddnport
        speed = cmd.speed

        startall = start_all_plugin.StartAll(vpn_uuid, vpn_vlanid,
                                             vpn_service_port, ddn_port, speed)

        res = startall.start()
        rsp = VpnStatusResponse()
        if res:
            rsp.vpnStatus = "UP"
            rsp.massage = "VPN start successful"
        else:
            rsp.vpnStatus = "DOWN"
            rsp.error = "VPN start failed"

        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def destroy_vpn(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        vpn_vlanid = cmd.vpnvlanid
        ddn_port = cmd.ddnport
        vpn_service_port = cmd.vpnport

        destroy_vpn_all = destroy_vpn_plugin.DestroyVpn(vpn_uuid,
                                                        vpn_vlanid, ddn_port,
                                                        vpn_service_port)

        res = destroy_vpn_all.destroy_vpn()

        rsp = VpnStatusResponse()
        if res:
            rsp.massage = 'destroy successful'
        else:
            rsp.error = 'destroy failed'

        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def client_info(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        client_info = client_conf_plugin.ClientInfo(vpn_uuid)
        client_dist = client_info.clinet_info()
        rsp = VpnCertResponse()
        rsp.ca_crt = client_dist['ca_crt']
        rsp.client_crt = client_dist['ca_crt']
        rsp.client_key = client_dist['ca_crt']
        rsp.client_conf = client_dist['ca_crt']

        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def login_info(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        username = cmd.username
        passwd = cmd.passwd

        setinfo = login_info_plugin.LoginInfo(vpn_uuid, username, passwd)
        res = setinfo.set_login_info()
        rsp = VpnStatusResponse()

        if res:
            rsp.massage = 'Client passwd set successful'
        else:
            rsp.error = 'Client passwd set failed'
        return jsonobject.dumps(rsp)

    @vpnagent.replyerror
    def init_vpn(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        vpn_uuid = cmd.vpnuuid
        host_ip = cmd.hostip
        vpn_vlanid = cmd.vpnvlanid
        vpn_service_port = cmd.vpnport
        ddn_port = cmd.ddnport
        speed = cmd.speed
        username = cmd.username
        passwd = cmd.passwd

        # cert
        vpn_cert = cert_plugin.VpnCert(vpn_uuid)
        res_cert = vpn_cert.create_vpn_cert()

        # conf
        logger.info('Init_vpn start create vpn conf')
        vpn_conf = conf_plugin.VpnConf(vpn_uuid, host_ip, vpn_service_port)
        res_conf = vpn_conf.create_conf()

        # client passwd
        setinfo = login_info_plugin.LoginInfo(vpn_uuid, username, passwd)
        res_passwd = setinfo.set_login_info()

        # service
        vpn_service = vpn_service_plugin.VpnService(vpn_uuid,
                                                    vpn_vlanid, vpn_service_port)
        res_service = vpn_service.vpn_up_down("start")
        # vport
        v_interface = vinterface_plugin.Vinterface(vpn_vlanid,
                                                   ddn_port, vpn_service_port)
        res_vport = v_interface.add_br_vport()
        # rate-limiting
        net_rate_limiting = rate_limiting_plugin.RateLimiting(vpn_service_port, speed)
        res_rate = net_rate_limiting.set_rate_limiting()

        rsp = VpnStatusResponse()
        if res_cert and res_conf and res_service and res_vport and res_rate and res_passwd:
            rsp.massage = 'Vpn create successful'
            rsp.vpnStatus = "UP"
        else:
            res_info = {"cert": res_cert, "service": res_service, "port": res_vport,
                        "rate-limiting": res_rate, "passwd": res_passwd}

            destroy_vpn_all = destroy_vpn_plugin.DestroyVpn(vpn_uuid,
                                                            vpn_vlanid, ddn_port,
                                                            vpn_service_port)

            res_destroy = destroy_vpn_all.destroy_vpn()
            res_info["destroy"] = res_destroy
            rsp.massage = res_info
            rsp.success = "false"
            rsp.vpnStatus = "DOWN"
            rsp.error = "Vpn create failed"

        return jsonobject.dumps(rsp)

    def start(self):
        self.host_uuid = None

        http_server = vpnagent.get_http_server()
        http_server.register_sync_uri(self.CERT_PATH, self.create_cert)
        http_server.register_sync_uri(self.CONF_PATH, self.conf_vpn)
        http_server.register_sync_uri(self.SERVICE_PATH, self.vpn_service)
        http_server.register_sync_uri(self.VPORT_PATH, self.vpn_vport)
        http_server.register_sync_uri(self.LIMIT_PATH, self.rate_limiting)
        http_server.register_sync_uri(self.START_PATH, self.start_all)
        http_server.register_sync_uri(self.DESTROY_PATH, self.destroy_vpn)
        http_server.register_sync_uri(self.CLIENT_PATH, self.client_info)
        http_server.register_sync_uri(self.LOGIN_PATH, self.login_info)
        http_server.register_sync_uri(self.VPN_PATH, self.init_vpn)

    def stop(self):
        pass

    def configure(self, config):
        self.config = config
