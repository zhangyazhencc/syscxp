#!/usr/bin/env python
#coding:utf-8

from syscxplib.utils import log
import sys
import subprocess
import os

logger = log.get_logger(__name__)

class VpnService(object):

    def __init__(self, UUID, VLANID, VPN_SERVICE_PORT):
        self.UUID = UUID
        self.VPN_DIR = '/var/lib/syscxp/vpndata/vpn-{}'.format(self.UUID)
        self.BR_NAME = "vpn-br-{}".format(VLANID)
        self.VPN_VPORT = "tap-vpn-{}".format(VPN_SERVICE_PORT)

    def exec_command(self, cmd):
        res = subprocess.call(cmd, shell=True, stdout=sys.stdout, stderr=sys.stderr)
        return res

    def vpn_status(self):
        cmd = 'pgrep -f "config {}"'.format(self.VPN_DIR)
        res = os.popen(cmd).read().split()
        if len(res) == 1:
            return True
        else:
            return False

    def vpn_start(self):
        logger.info("start vpn service")
        cmd = 'openvpn --config {} &'.format(os.path.join(self.VPN_DIR, 'server.conf'))
        self.exec_command(cmd)
        check_br = 'brctl show |grep {}'.format(self.BR_NAME)
        check_vp = 'brctl show |grep {}'.format(self.VPN_VPORT)
        res_br = self.exec_command(check_br)
        res_vp = self.exec_command(check_vp)

        if res_br == 0 and res_vp !=0:
            add_cmd = "brctl addif {} {} && ifconfig {} up".format(self.BR_NAME,
                                                               self.VPN_VPORT, self.VPN_VPORT)
            self.exec_command(add_cmd)

        res = self.vpn_status()
        if not res:
            logger.error("Vpn service start failed")
        return res

    def vpn_stop(self):
        logger.info("stop vpn service")
        cmd = 'vpn_pid=`pgrep -f "config {}"`&& kill -9 $vpn_pid'.format(self.VPN_DIR)
        self.exec_command(cmd)
        res = self.vpn_status()
        if res:
            logger.error("Vpn service stop failed")
        return res

    def vpn_restart(self):
        self.vpn_stop()
        res = self.vpn_start()
        return res

