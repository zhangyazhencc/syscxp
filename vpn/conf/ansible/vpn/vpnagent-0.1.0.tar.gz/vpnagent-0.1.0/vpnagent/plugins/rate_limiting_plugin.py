#!/usr/bin/env python
#coding:utf-8

from syscxplib.utils import log
import subprocess
import sys
import os

logger = log.get_logger(__name__)

class RateLimiting(object):

    def __init__(self, VPN_SERVICE_PORT, SPEED):
        # SPEED Kb/s
        self.VPN_VPORT = "tap-vpn-{}".format(VPN_SERVICE_PORT)
        self.VPN_SPEED = SPEED


    def exec_command(self, cmd):
        subprocess.call(cmd, shell=True, stdout=sys.stdout, stderr=sys.stderr)


    def set_rate_limiting(self):
        logger.info("set rate-limiting for %s" % self.VPN_VPORT)
        cmd = "wondershaper {} {} {}".format(self.VPN_VPORT,
                                             self.VPN_SPEED, self.VPN_SPEED)
        self.exec_command(cmd)
        return self.check_rate_limiting()

    def clean_rate_limiting(self):
        logger.info("clear rate-limiting for %s" % self.VPN_VPORT)
        cmd = "wondershaper clear {}".format(self.VPN_VPORT)
        self.exec_command(cmd)
        return self.check_rate_limiting()

    def check_rate_limiting(self):
        cmd = "tc class show dev {} |grep {} >> /dev/null".format(self.VPN_VPORT, self.VPN_SPEED)
        res = os.system(cmd)

        if res == 0:
            return True
        else:
            return False


