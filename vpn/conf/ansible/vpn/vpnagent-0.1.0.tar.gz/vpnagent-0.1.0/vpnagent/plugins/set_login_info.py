#!/usr/bin/env python
#coding:utf-8

from syscxplib.utils import log
import os

logger = log.get_logger(__name__)

class LoginInfo(object):
    def __init__(self, uuid, username, passwd):
        self.UUID = uuid
        self.USERNAME = username
        self.PASSWD = passwd
        self.BASE_DIR = '/var/lib/syscxp/vpndata/'
        self.VPN_DIR = os.path.join(self.BASE_DIR, 'vpn-{}'.format(self.UUID))
        self.FILENAME = os.path.join(self.VPN_DIR, "pw.txt")

    def cehck_info(self):
        with open(self.FILENAME, 'rb') as fn:
            fn_list = fn.read().split()
            if self.USERNAME in fn_list and self.PASSWD in fn_list:
                return True
            else:
                return False

    def set_info(self):
        logger.info("write user/passwd to file")
        with open(self.FILENAME, 'wb') as fn:
            fn.write(self.USERNAME + '\n')
            fn.write(self.PASSWD + '\n')

        res = self.cehck_info()
        return res



