#!/usr/bin/env python
#coding:utf-8

from syscxplib.utils import log
import os

logger = log.get_logger(__name__)

class PushCert(object):
    def __init__(self, uuid, cert_dict):
        self.UUID = uuid
        self.BASE_DIR = '/var/lib/syscxp/vpndata/'
        self.VPN_KEYS = os.path.join(self.BASE_DIR, 'vpn-{}/keys'.format(self.UUID))
        self.CA_CERT = {}
        self.CA_KEY = {}
        self.SERVER_CERT = {}
        self.SERVER_KEY = {}
        self.DH_1024 = dict()

        self.CA_CERT['ca.crt'] = cert_dict['ca_crt']
        self.CA_KEY['ca.key'] = cert_dict['ca_key']
        self.SERVER_CERT['server.crt'] = cert_dict['server_crt']
        self.SERVER_KEY['server.key'] = cert_dict['server_key']
        self.DH_1024['dh1024.pem'] = cert_dict['dh1024_pem']

    def write_file(self, dict_):
        filename = dict_.keys()[0]
        filecontent = dict_.values()[0]
        logger.info("Write %s to file" % filename)
        newfile = os.path.join(self.VPN_KEYS, filename)
        with open(newfile, 'wb') as fn:
            fn.write(filecontent)

    def receive_cert_info(self):
        if not os.path.isdir(self.VPN_KEYS):
            os.makedirs(self.VPN_KEYS)
        os.chdir(self.VPN_KEYS)
        for dict_ in [self.CA_CERT, self.CA_KEY, self.SERVER_CERT, self.SERVER_KEY, self.DH_1024]:
            self.write_file(dict_)
