#!/usr/bin/env python
#coding:utf-8
import os
import re


class ClientInfo(object):
    ''' Return client.conf info '''
    def __init__(self, uuid):
        self.UUID = uuid
        self.BASE_DIR = '/var/lib/syscxp/vpndata/'
        self.VPN_DIR = os.path.join(self.BASE_DIR, 'vpn-{}'.format(self.UUID))

    def clinet_info(self):
        client_dist = {}

        os.chdir(self.VPN_DIR)
        files_list = ['ca.crt', 'client.crt', 'client.key', 'client.conf']

        for filename in files_list:
            with open(filename, 'rb') as conf:
                key_name = re.sub('\.', '_',  filename)
                client_dist[key_name] = conf.read()

        return client_dist



