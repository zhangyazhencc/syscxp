#!/usr/bin/env python
#coding:utf-8
import os
from syscxplib.utils import log

logger = log.get_logger(__name__)

class VpnConf(object):

    def __init__(self, uuid, hostip, vpn_port):
        self.UUID = uuid
        self.SERVER_IP = hostip
        self.VPN_SERVICE_PORT = vpn_port
        self.VPN_BASE_DIR = "/var/lib/syscxp/vpndata/vpn-{}".format(uuid)
        self.CERT_PATH = os.path.join(self.VPN_BASE_DIR, "keys")
        self.VPN_VPORT_NAME = "tap-vpn-{}".format(self.VPN_SERVICE_PORT)
        self.CA_PATH = os.path.join(self.CERT_PATH, "ca.crt")
        self.SERVER_CERT_PATH = os.path.join(self.CERT_PATH, "server.crt")
        self.DH_PATH = os.path.join(self.CERT_PATH, "dh1024.pem")
        self.SERVER_KEY_PATH = os.path.join(self.CERT_PATH, "server.key")
        self.NUM_MAXNUM = "1 5"  # 用于检测，每秒发送UDP包，最多发送5次，5次无响应后切换服务器
        self.IP_PORT = " ".join([self.SERVER_IP, self.VPN_SERVICE_PORT])
        self.CHECKPSW = "{}/checkpsw.sh via-env".format(self.VPN_BASE_DIR)

        self.SERVER_CONF = [
            {"local": self.SERVER_IP},
            {"port": self.VPN_SERVICE_PORT},
            {"proto": "udp"},
            {"dev": self.VPN_VPORT_NAME},
            {"ca": self.CA_PATH},
            {"cert": self.SERVER_CERT_PATH},
            {"dh": self.DH_PATH},
            {"key": self.SERVER_KEY_PATH},
            {"topology": "subnet"},
            {"server-bridge": "nogw"},
            {"mode": "server"},
            {"tls-server": ""},
            {"keepalive": self.NUM_MAXNUM},
            {"client-to-client": ""},
            {"cipher": "AES-256-CBC"},
            {"script-security": "3"},
            {"comp-lzo": ""},
            {"persist-key": ""},
            {"persist-tun": ""},
            {"status": "/var/log/openvpn-status.log"},
            {"log": "/var/log/openvpn.log"},
            {"log-append": "/var/log/openvpn.log"},
            {"verb": "4"},
            {"mute": "20"},
            {"explicit-exit-notify": "1"},
#            {"auth-user-pass-verify": self.CHECKPSW},
#            {"client-cert-not-required": ""},
#            {"username-as-common-name": ""},
        ]

        self.CLIENT_CONF = [
            {"client": ""},
            {"dev": "tap"},
            {"proto": "udp"},
            {"remote": self.IP_PORT},
            {"ca": "ca.crt"},
            {"cert": "client.crt"},
            {"key": "client.key"},
            {"comp-lzo": ""},
            {"cipher": "AES-256-CBC"},
            {"verb": "4"},
            {"log": "/var/log/openvpn.log"},
            {"log-append": "/var/log/openvpn.log"},
            {"mute": "20"},
            {"nobind": ""},
#            {"auth-nocache": ""},
#            {"auth-user-pass": "pw.txt"},
        ]

    def check_file_status(self, filename):
        os.chdir(self.VPN_BASE_DIR)
        file_list = os.popen('ls').read().split()
        if filename in file_list:
            return True
        else:
            logger.error("create %s failed" % filename)


    def start_create_conf(self, values_list, conf_name):
        logger.info("Create %s" %conf_name)
        conf_ = ""
        for l_index in range(len(values_list)):
            for key, value in values_list[l_index].items():
                conf_ = conf_ + " ".join([key, value]) + "\n"
        with open(conf_name, 'wb') as conf_values:
            conf_values.write(conf_)

    def create_conf(self):
        conf_files = ['server.conf', 'client.conf']
        res = True
        for name in conf_files:
            if "server" in name:
                conf_ = self.SERVER_CONF
            elif "client" in name:
                conf_ = self.CLIENT_CONF
            logger.info("start create %s " % name)
            conf_name = os.path.join(self.VPN_BASE_DIR, name)
            self.start_create_conf(conf_, conf_name)
            if not self.check_file_status(name):
                res = False
        return res
