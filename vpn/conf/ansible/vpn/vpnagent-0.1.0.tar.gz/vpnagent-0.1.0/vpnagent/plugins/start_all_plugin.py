#!/usr/bin/env python
#coding:utf-8

from vpnagent.plugins import vpn_service_plugin
from vpnagent.plugins import vinterface_plugin
from vpnagent.plugins import rate_limiting_plugin
import pdb

class StartAll(object):
    def __init__(self, UUID, VLANID, VPN_SERVICE_PORT, DDN_PORT, SPEED):
        self.UUID = UUID
        self.VLANID = VLANID
        self.VPN_SERVICE_PORT = VPN_SERVICE_PORT
        self.DDN_PORT = DDN_PORT
        self.SPEED = SPEED


    def start(self):

        service_vpn = vpn_service_plugin.VpnService(self.UUID, self.VLANID, self.VPN_SERVICE_PORT)
        service_vpn.vpn_up_down('start')
        res_vpn = service_vpn.vpn_status()


        vport = vinterface_plugin.Vinterface(self.VLANID, self.DDN_PORT, self.VPN_SERVICE_PORT)
        vport.add_br_vport()
        res_vport = vport.check_br_vport()


        rate_limit = rate_limiting_plugin.RateLimiting(self.VPN_SERVICE_PORT, self.SPEED)
        rate_limit.set_rate_limiting()
        res_rate_limit = rate_limit.check_rate_limiting()



        if res_vpn and res_vport and res_rate_limit:
            return True
        else:
            return False
