#!/usr/bin/env python
#coding:utf-8

from syscxplib.utils import log
import os
import stat

logger = log.get_logger(__name__)

class LoginInfo(object):

    def __init__(self, uuid, username, passwd):
        self.UUID = uuid
        self.USERNAME = username
        self.PASSWD = passwd
        self.BASE_DIR = "/var/lib/syscxp/vpndata/"
        self.VPN_DIR = os.path.join(self.BASE_DIR, "vpn-{}".format(self.UUID))
        self.FILENAME = os.path.join(self.VPN_DIR, "pw.txt")
        self.CHECKPSW = "()/checkpsw.sh via-env".format(self.VPN_DIR)
        self.CHECKPSW_LOG = "{}/openvpn-password.log".format(self.VPN_DIR)
        self.CHECKPSW_FILE = os.path.join(self.VPN_DIR, "psw-file")
        self.CHECK_SH = os.path.join(self.VPN_DIR, "checkpsw.sh")


        self.docs_ = '''
TIME_STAMP=`date "+%Y-%m-%d %T"`

###########################################################

if [ ! -r "${PASSFILE}" ]; then
  echo "${TIME_STAMP}: Could not open password file \"${PASSFILE}\" for reading." >> ${LOG_FILE}
  exit 1
fi

CORRECT_PASSWORD=`awk '!/^;/&&!/^#/&&$1=="'${username}'"{print $2;exit}' ${PASSFILE}`

if [ "${CORRECT_PASSWORD}" = "" ]; then 
  echo "${TIME_STAMP}: User does not exist: username=\"${username}\", password=\"${password}\"." >> ${LOG_FILE}
  exit 1
fi

if [ "${password}" = "${CORRECT_PASSWORD}" ]; then 
  echo "${TIME_STAMP}: Successful authentication: username=\"${username}\"." >> ${LOG_FILE}
  exit 0
fi

echo "${TIME_STAMP}: Incorrect password: username=\"${username}\", password=\"${password}\"." >> ${LOG_FILE}
exit 1
'''

    def check_file_status(self):
        os.chdir(self.VPN_DIR)
        file_list = os.popen('ls').read().split()
        files = [self.FILENAME, self.CHECK_SH, self.CHECKPSW_FILE]
        for filename in files:
            if os.path.basename(filename) in file_list:
                continue
            else:
                logger.error("create %s failed" % os.path.basename(filename))
        return True

    def set_client_info(self):
        logger.info("write user/passwd to client file")
        with open(self.FILENAME, 'wb') as fn:
            fn.write(self.USERNAME + '\n')
            fn.write(self.PASSWD + '\n')


    def set_server_info(self):
        logger.info("write server passwd file")
        with open(self.CHECK_SH, 'wb') as fsh:
            fsh.write("#!/bin/sh" + "\n\n")
            fsh.write('PASSFILE="{}"'.format(self.CHECKPSW_FILE) + '\n')
            fsh.write('LOG_FILE="{}"'.format(self.CHECKPSW_LOG))
            fsh.write(self.docs_)

        with open(self.CHECKPSW_FILE, 'wb') as fpw:
            fpw.write("{} {}".format(self.USERNAME, self.PASSWD))

        os.chmod(self.CHECK_SH, stat.S_IRWXU)
        os.chmod(self.CHECKPSW_FILE, stat.S_IRUSR | stat.S_IWUSR)

    def set_login_info(self):
        self.set_client_info()
        self.set_server_info()
        res = self.check_file_status()
        return res

