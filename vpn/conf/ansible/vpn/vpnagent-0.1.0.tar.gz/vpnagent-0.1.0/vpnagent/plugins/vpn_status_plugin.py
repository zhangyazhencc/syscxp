#!/usr/bin/env python
#coding:utf-8
import re
import os
from vpnagent.plugins import vpn_service_plugin
from vpnagent.plugins import vinterface_plugin
from syscxplib.utils import log

logger = log.get_logger(__name__)

class VpnStatus(object):
    def __init__(self, uuid):
        self.UUID = uuid
        self.VPN_SERVER_FILE = '/var/lib/syscxp/vpndata/vpn-{}/server.conf'.format(self.UUID)
        self.VPN_SERVICE_PORT = None
        self.VPN_DEV = None
        self.DDN_PORT = None
        self.VLANID = None
        self.RES = True

    def vpn_info(self):
        logger.info("VPN_SERVER_FILE %s" % self.VPN_SERVER_FILE)
        try:
            if os.path.isfile(self.VPN_SERVER_FILE):
                with open(self.VPN_SERVER_FILE, 'rb') as fv:
                    server_info = fv.read()
                    self.VPN_SERVICE_PORT = re.search(r"port .*\d", server_info).group().split()[1]
                    self.VPN_DEV = re.search(r"dev tap-.*\d", server_info).group().split()[1]
                    cmd = "brctl show |grep -B1 {}|head -1|awk '{{ print $1,$4 }}'".format(self.VPN_DEV)
                    vports = os.popen(cmd).read().strip().split()
                    self.DDN_PORT, self.VLANID = vports[1].split('.')
    #            logger.debug("Vpn info UUID %s, VPN_SERVICE_PORT %s, VPN_DEV %s, DDN_PORT %s, VLANID %s"
    #                        % (self.UUID, self.VPN_SERVICE_PORT, self.VPN_DEV, self.DDN_PORT, self.VLANID))
        except Exception, err:
            logger.info("%s" % err)
            self.RES = False

    def all_status(self):

        self.vpn_info()
        if self.RES:
            vpn_service = vpn_service_plugin.VpnService(self.UUID, self.VLANID,
                                                        self.VPN_SERVICE_PORT)
            vpn_vport = vinterface_plugin.Vinterface(self.VLANID,
                                                     self.DDN_PORT, self.VPN_SERVICE_PORT)

            res_vport = vpn_vport.check_br_vport()
            res_service = vpn_service.vpn_status()

            if res_vport and res_service:

                logger.info("UUID %s vpn ports UP, service UP." % self.UUID)
                return True
            else:
                logger.info("UUID %s vpn ports UP %s, service UP %s." % (self.UUID, res_vport, res_service))
                return False
        else:
            return False

