#!/usr/bin/env python
#coding:utf-8

from syscxplib.utils import log
from vpnagent.plugins import vpn_service_plugin
from vpnagent.plugins import vinterface_plugin
import os

logger = log.get_logger(__name__)

class DestroyVpn(object):

    def __init__(self, UUID, VLANID, DDN_PORT, VPN_SERVICE_PORT):
        self.UUID = UUID
        self.VLANID = VLANID
        self.DDN_PORT = DDN_PORT
        self.VPN_SERVICE_PORT = VPN_SERVICE_PORT

    def destroy_vpn(self):
        logger.info("start destroy vpn")
        vpn_service = vpn_service_plugin.VpnService(self.UUID, self.VLANID, self.VPN_SERVICE_PORT)
        vpn_vport = vinterface_plugin.Vinterface(self.VLANID,
                                                 self.DDN_PORT, self.VPN_SERVICE_PORT)
        vpndir = vpn_service.VPN_DIR

        vpn_service.vpn_up_down("stop")
        vpn_vport.del_br_vport()
        os.system("rm -rf {}".format(vpndir))

        res_vport = vpn_vport.check_br_vport()
        res_service = vpn_service.vpn_status()

        if res_vport is False and res_service is False:
            return True
        elif res_vport is True:
            logger.error("Delete port failed")
        elif res_service is True:
            logger.error("Delete vpn service failed")

