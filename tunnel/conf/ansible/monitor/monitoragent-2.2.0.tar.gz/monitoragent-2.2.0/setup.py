from setuptools import setup, find_packages
import sys, os

version = '2.2.0'

setup(name='monitoragent',
      version=version,
      description="Syscxp Monitor agent REST service",
      long_description="""\
Syscxp Monitor agent REST service""",
      classifiers=[],  # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='syscxp kvm python agent REST',
      author='',
      author_email='',
      url='http://syscxp.org',
      license='Apache License 2',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=True,
      install_requires=[
          # -*- Extra requirements: -*-
          'requests==2.18.4'
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
