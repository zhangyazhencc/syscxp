'''

@author: frank
'''
from monitoragent import monitoragent
from syscxplib.utils import jsonobject
from syscxplib.utils import http
from syscxplib.utils.bash import *
import threading
import Queue
import time
import re
import itertools
import json
import socket
import traceback
import ConfigParser
from monitoragent.plugins.icmp_service import call_prog, tunnels_running, get_tunnel_values, del_tunnel_monitor, update_tunnel_monitor, add_tunnel_monitor
from syscxplib.utils import log
logger = log.get_logger(__name__)
config = ConfigParser.ConfigParser()
config.read("/etc/monitor/monitoragent.conf")
#TRANSFER_RPC_IP = config.get("monitor", "transfer_rpc_ip")
TRANSFER_RPC_IP = '192.168.211.6'
PING_INTERVAL = 30
PING_COUNT = 100
ping_threads = {}
monitor_threads = {}
class RPCClient(object):
    def __init__(self, addr, codec=json):
        self._socket = socket.create_connection(addr, timeout=20)
        self._id_iter = itertools.count()
        self._codec = codec

    def _message(self, name, *params):
        return dict(id=self._id_iter.next(),
                    params=list(params),
                    method=name)

    def call(self, name, *params):
        req = self._message(name, *params)
        id = req.get('id')
        mesg = self._codec.dumps(req)
        self._socket.sendall(mesg)
        resp = self._socket.recv(4096)
        resp = self._codec.loads(resp)

        if resp.get('id') != id:
            raise Exception("expected id=%s, received id=%s: %s"
                            % (id, resp.get('id'), resp.get('error')))

        if resp.get('error') is not None:
            raise Exception(resp.get('error'))

        return resp.get('result')

    def close(self):
        self._socket.close()

class ThreadPing(threading.Thread):
    def __init__(self, t_name, queue, tunnel_values):
        threading.Thread.__init__(self, name=t_name)
        self.data = queue
        self.tunnel_values = tunnel_values
        self.ping_interval = float(PING_INTERVAL) / float(PING_COUNT)
        self.flag = 0
        self.thread_stop = False
        self.lossPerc = None
        self.rtt_avg = None

    def run(self):
        logger.info('ThreadPing starting')
        result = None
        vlan = self.tunnel_values['local_vlan']
        ifvlan = self.tunnel_values['if_name']
        netns_name = self.tunnel_values['netns_name']
        remote_ip = self.tunnel_values['remote_ip']
        local_vtep_ip = self.tunnel_values['local_vtep_ip']
        command = 'ip netns exec %s ping -c %s -I %s -i  %s %s' % (netns_name,PING_COUNT, ifvlan, self.ping_interval, remote_ip)
        while not self.thread_stop:
            if self.flag == 0:
                stdout = call_prog(command)
                self.flag = 1
            if self.flag == 1:
                stdout = call_prog(command)
                if stdout:
                    result = stdout.split('---')[-1]
                    if 'packet loss' in result:
                        self.lossPerc = re.match(r'.*? (\d+)% packet loss, .*?', result, re.DOTALL).group(1)
                    if 'rtt' in result:
                        self.rtt_avg = re.match(r'.*?min/avg/max/mdev = (\d.*\d).*', result, re.DOTALL).group(1).split('/')[1]
                    #logger.info("local_vtep_ip:{}--vlanid:{}--lostPer:{}--rtt:{}".format(local_vtep_ip,vlan, self.lossPerc, self.rtt_avg))
                    self.data.put((local_vtep_ip,vlan, self.lossPerc, self.rtt_avg))
                else:
                    time.sleep(30)

    def stop(self):
        self.thread_stop = True
        logger.info('ThreadPing stop')


class ThreadMonitor(threading.Thread):
    def __init__(self, t_name, queue,):
        threading.Thread.__init__(self, name=t_name)
        self.data = queue
        self.thread_stop = False

    def run(self):
        logger.info('ThreadMonitor starting')
        while not self.thread_stop:
            (local_vtep_ip, vlan, lossPer, rtt_avg) = self.data.get()
            logger.info("vlanid:{}--lostPer:{}--rtt:{}".format(vlan, lossPer, rtt_avg))
            lossPer = dict(endpoint=local_vtep_ip, metric='tunnel.packets.lost', value='%s' % lossPer,
                           step=PING_INTERVAL,counterType='GAUGE', tags='ifName=Vlanif%s' % vlan, timestamp=0)
            rttAvg = dict(endpoint=local_vtep_ip, metric='tunnel.packets.rtt', value='%s' % rtt_avg, step=PING_INTERVAL,
                          counterType='GAUGE', tags='ifName=Vlanif%s' % vlan, timestamp=0)
            count = 0
            while count <= 3:
                try:
                    rpc = RPCClient((TRANSFER_RPC_IP, 8433))
                    logger.info("=============begin to push")
                    rpc.call("Transfer.Update", [lossPer, rttAvg])
                    logger.info("=============end push")
                    break
                except Exception, e:
                    error_trace = traceback.format_exc()
                    logger.error(error_trace)
                    count += 1

    def stop(self):
        self.thread_stop = True
        logger.info('ThreadMonitor stop')

class Singleton(object):
    def __new__(cls, *args, **kw):
        if not hasattr(cls, '_instance'):
            orig = super(Singleton, cls)
            cls._instance = orig.__new__(cls, *args, **kw)
        return cls._instance


class IcmpAgent(Singleton):
    __first_init = True

    def __init__(self):
        if self.__first_init:
            self.queue = Queue.Queue()
            self.threadmonitor = None
            self.threadPing = None
            self.threadingicmp = None
            self.thread_running = True
            IcmpAgent.__first_init = False

    def _threadingicmp(self):
        logger.info('IcmpAgent start.')
        while self.thread_running:
            for key in tunnels_running.keys():
                tunnel_values = tunnels_running[key]
                if tunnel_values['init_interface']:
                    if key not in ping_threads.keys():
                        self.threadPing = ThreadPing('ThreadingPing', self.queue, tunnel_values)
                        ping_threads[key] = self.threadPing
                        self.threadPing.start()
                    if tunnel_values['ipvlan_change']:
                        old_threadPing = ping_threads.pop(key)
                        old_threadPing.stop()
                        self.threadPing = ThreadPing('ThreadingPing', self.queue, tunnel_values)
                        ping_threads[key] = self.threadPing
                        self.threadPing.start()
                        tunnels_running[key]['ipvlan_change'] = False

                for key in ping_threads.keys():
                    if key not in tunnels_running.keys():
                        pingthread = ping_threads.pop(key)
                        pingthread.stop()

            time.sleep(PING_COUNT)

    def start(self):
        try:
            logger.info('Agent   starting------------------')
            self.threadmonitor = ThreadMonitor('ThreadingMonitor', self.queue)
            self.threadmonitor.start()
            self.threadingicmp = threading.Thread(target=self._threadingicmp)
            self.threadingicmp.start()
        except Exception as e:
            logger.error(traceback.format_exc())

    def stop(self):
        self.threadmonitor.stop()
        self.threadPing.stop()
        self.thread_running = False
        logger.info('IcmpAgent stop')
        logger.info('IcmpAgent stop')


def _rec(line):
    re_line = re.match(r'.*?Bytes  (\d+.\d+) bits/sec.*?',line)
    if re_line is None:
        re_line = re.match(r'.*?Bytes   (\d+.\d+) bits/sec.*?', line)
    if re_line:
        return re_line.group(1)


class IcmpPlugin(monitoragent.MonitorAgent):
    AGENT_START_PATH = "/icmp/start_monitor"
    AGENT_STOP_PATH = "/icmp/stop_monitor"
    AGENT_UPDATE_PATH = "/icmp/update_monitor"

    @monitoragent.replyerror
    def start_monitor(self, req):
        returnobject = {}
        returnobject["msg"] = "success"
        returnobject["success"] = "True"
        cmd = eval(req[http.REQUEST_BODY])
        strategylist = cmd['strategyList']
        strategies = strategylist['strategies']
        for strategy in strategies:
            try:
                tunnel_values = get_tunnel_values(strategy)
                key = strategy['tunnel_id']
                add_tunnel_monitor(key, tunnel_values)
                logger.debug(http.path_msg(self.AGENT_START_PATH, ' start_monitor' % strategy))
            except Exception, e:
                error_trace = traceback.format_exc()
                logger.error(error_trace)
                logger.error(e)
                returnobject["msg"] = "no such tunnel strategy:" + str(strategy)
                returnobject["success"] = "False"
        return jsonobject.dumps(returnobject)

    @monitoragent.replyerror
    def stop_monitor(self, req):
        returnobject = {}
        returnobject["msg"] = "success"
        returnobject["success"] = "True"
        cmd = eval(req[http.REQUEST_BODY])
        tunnel_id = cmd["tunnel_id"]
        if tunnel_id not in tunnels_running.keys():
            returnobject["msg"] = "no such tunnel tunnel_id:" + str(tunnel_id)
            returnobject["success"] = "False"
            return jsonobject.dumps(returnobject)
        try:
            del_tunnel_monitor(tunnel_id)
        except Exception, e:
            error_trace = traceback.format_exc()
            logger.error(error_trace)
            logger.error(e)
            returnobject["msg"] = "no such tunnel, tunnel_id:" + str(tunnel_id)
            returnobject["success"] = "False"

        return jsonobject.dumps(returnobject)

    @monitoragent.replyerror
    def update_monitor(self, req):
        returnobject = {}
        returnobject["msg"] = "success"
        returnobject["success"] = "True"
        cmd = eval(req[http.REQUEST_BODY])
        strategylist = cmd['strategyList']
        strategies = strategylist['strategies']
        for strategy in strategies:
            try:
                tunnel_values = get_tunnel_values(strategy, mode="manual")
                key = strategy['tunnel_id']
                if key not in tunnels_running.keys():
                    returnobject["msg"] = "no such tunnel strategy:" + str(strategy)
                    returnobject["success"] = "False"
                    return jsonobject.dumps(returnobject)
                if tunnel_values['ipvlan_change']:
                    update_tunnel_monitor(key, tunnel_values)
            except Exception, e:
                error_trace = traceback.format_exc()
                logger.error(error_trace)
                logger.error(e)
                returnobject["msg"] = "no such tunnel strategy:" + str(strategy)
                returnobject["success"] = "False"
        return jsonobject.dumps(returnobject)

    def start(self):
        IcmpAgent().start()
        http_server = monitoragent.get_http_server()
        http_server.register_sync_uri(self.AGENT_START_PATH, self.start_monitor)
        http_server.register_sync_uri(self.AGENT_STOP_PATH, self.stop_monitor)
        http_server.register_sync_uri(self.AGENT_UPDATE_PATH, self.update_monitor)

    def stop(self):
        pass

    def configure(self, config):
        self.config = config

