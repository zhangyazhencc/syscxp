import threading
import requests
import subprocess
import traceback
import ConfigParser
import time
from syscxplib.utils import log
from syscxplib.utils.thread import AsyncThread

UPDATE_INTERVAL = 300
old_tunnels = {}
logger = log.get_logger(__name__)
tunnels_running = {}
config = ConfigParser.ConfigParser()
config.read("/etc/monitor/monitoragent.conf")
LINUX_LOCAL_IP = config.get("monitor", "host_ip")
FALCON_IP = config.get("monitor", "falcon_ip")
FALCON_PORT = config.get("monitor", "falcon_port")
_interface_init = None


@AsyncThread
def add_tunnel_monitor(key, tunnel_values):
    logger.info("add_tunnel_monitor start----------------------------")
    interface = Interface()
    tunnel_values['ip_vlan'] = tunnel_values['local_ip'] + '_' + tunnel_values['local_vlan']
    tunnel_values['if_name'] = tunnel_values['interface_name'] + "." + tunnel_values['local_vlan']
    tunnel_values['netns_name'] = tunnel_values['interface_name'] + "_" + tunnel_values['local_vlan']
    interface.init_interface(tunnel_values['interface_name'], tunnel_values['local_vlan'], tunnel_values['local_ip'])
    tunnel_values['init_interface'] = True
    tunnels_running[key] = tunnel_values


@AsyncThread
def update_tunnel_monitor(key, tunnel_values):
    logger.info("update_tunnel_monitor start----------------------------")
    interface = Interface()
    tunnel_values_running = tunnels_running[key]
    interface.destroy_interface(tunnel_values_running['netns_name'], tunnel_values_running['if_name'])
    tunnel_values['ip_vlan'] = tunnel_values['local_ip'] + '_' + tunnel_values['local_vlan']
    tunnel_values['if_name'] = tunnel_values['interface_name'] + "." + tunnel_values['local_vlan']
    tunnel_values['netns_name'] = tunnel_values['interface_name'] + "_" + tunnel_values['local_vlan']
    interface.init_interface(tunnel_values['interface_name'], tunnel_values['local_vlan'], tunnel_values['local_ip'])
    tunnel_values['init_interface'] = True
    tunnels_running[key] = tunnel_values


@AsyncThread
def del_tunnel_monitor(key):
    logger.info("del_tunnel_monitor start----------------------------")
    tunnel_values = tunnels_running[key]
    interface = Interface()
    interface.destroy_interface(tunnel_values['netns_name'], tunnel_values['if_name'])
    interface.destroy_netns(tunnel_values['netns_name'])
    del tunnels_running[key]


def get_tunnel_values(strategy):
    logger.info("get_tunnel_values start----------------------------")
    tunnel_id = strategy['tunnel_id']
    tunnel_values = {}
    local_host = [local_end[0] for local_end in strategy.items() if LINUX_LOCAL_IP in local_end][0]
    if local_host == 'hostA_ip':
        local_ip = strategy['endpointA_mip']
        tunnel_values['local_ip'] = local_ip
        tunnel_values['local_vlan'] = str(strategy['endpointA_vid'])
        tunnel_values['remote_ip'] = strategy['endpointB_mip'].split('/')[0]
        tunnel_values['local_vtep_ip'] = strategy['endpointA_ip']
        tunnel_values['interface_name'] = strategy['endpointA_interface']
    elif local_host == 'hostB_ip':
        tunnel_values['local_ip'] = strategy['endpointB_mip']
        tunnel_values['local_vlan'] = str(strategy['endpointB_vid'])
        tunnel_values['remote_ip'] = strategy['endpointA_mip'].split('/')[0]
        tunnel_values['local_vtep_ip'] = strategy['endpointB_ip']
        tunnel_values['interface_name'] = strategy['endpointB_interface']
    ip_vlan = tunnel_values['local_ip'] + '_' + tunnel_values['local_vlan']
    tunnel_values['ipvlan_change'] = False
    tunnel_values['init_interface'] = False
    if tunnel_id in tunnels_running.keys() and ip_vlan != tunnels_running[tunnel_id].get('ip_vlan', None):
        tunnel_values['ipvlan_change'] = True
    return tunnel_values


def get_tunnels():
    try:
        logger.info("get tunnels start----------")
        logger.info(tunnels_running)
        resp = requests.get('http://%s:%s/monitoring/strategy/list_by_host_ip/%s' % (FALCON_IP, FALCON_PORT, LINUX_LOCAL_IP), timeout=30)
        resp = resp.json()
        strategylist = resp.get('strategyList')
        strategies = strategylist.get('strategies')
        tunnels = {}
        for strategy in strategies:
            tunnel_id = strategy['tunnel_id']
            tunnel_values = get_tunnel_values(strategy)
            tunnels[tunnel_id] = tunnel_values
        return tunnels
    except Exception as e:
        logger.warning('Warning{}:{}'.format(type(e), e))
        logger.error(traceback.format_exc())


def call_prog(cmd):
    logger.info('Command:{}'.format(cmd))
    stdout, stderr = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      shell=True).communicate()
    if stderr != '':
        logger.info(stderr)
    if stdout:
        return stdout

def get_interface_init():
    global _interface_init
    return _interface_init


def set_interface_init():
    global _interface_init
    if not _interface_init:
        _interface_init = interfaceInit()

    return _interface_init

class Interface(object):
    @staticmethod
    def init_interface(interface_name, vlan_id, ip_addr):
        if_name = interface_name + "." + vlan_id
        netns_name = interface_name + "_" + vlan_id
        call_prog('vconfig add %s %s' % (interface_name, vlan_id))
        call_prog('ip netns add %s' % netns_name)
        call_prog('ip li set %s netns %s' % (if_name, netns_name))
        call_prog('ip netns exec %s ifconfig %s %s up' % (netns_name, if_name, ip_addr))

    @staticmethod
    def destroy_interface(netns_name, if_name):
        call_prog('ip netns exec %s ip link delete dev %s' % (netns_name, if_name))

    @staticmethod
    def destroy_netns(netns_name):
        call_prog('ip netns delete %s' % netns_name)


class interfaceInit(object):
    def __init__(self):
        self.interfacethread = threading.Thread(target=self._run)
        self.thread_running = True

    def _run(self):
        logger.info('interfaceInit start.')
        while self.thread_running:
            try:
                global old_tunnels
                new_tunnels = get_tunnels()
                if new_tunnels:
                    for key in new_tunnels.keys():
                        tunnel_values = new_tunnels.get(key)
                        if key in old_tunnels.keys() and tunnel_values['ipvlan_change']:
                            update_tunnel_monitor(key, tunnel_values)

                        if key not in old_tunnels.keys():
                            add_tunnel_monitor(key, tunnel_values)

                    for key in old_tunnels.keys():
                        if key not in new_tunnels.keys():
                            del_tunnel_monitor(key)
                    old_tunnels = new_tunnels

            except Exception as e:
                error_trace = traceback.format_exc()
                logger.error(error_trace)
            time.sleep(UPDATE_INTERVAL)

    def start(self):
        self.interfacethread.setDaemon(True)
        self.interfacethread.start()

    def stop(self):
        self.thread_running = False