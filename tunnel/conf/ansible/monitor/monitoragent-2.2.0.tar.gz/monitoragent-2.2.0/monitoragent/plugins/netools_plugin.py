from monitoragent import monitoragent
from syscxplib.utils import jsonobject
from syscxplib.utils import http
from syscxplib.utils import log
from syscxplib.utils import lock
from syscxplib.utils.bash import *
from syscxplib.utils.thread import AsyncThread
import subprocess
import threading
import copy

logger = log.get_logger(__name__)

# formatter:
# {
#     taskid1:[result1,result2]
#     taskid2:[result1,result2]
# }
task_data = {}

def network_command(command,publish_ip):
    commands = None

    if "ping" == command and publish_ip:
        commands = "unbuffer ping -c 4 %s" %publish_ip
    if "trace" == command and publish_ip:
        commands = "unbuffer tracepath -n %s" %publish_ip

    return commands

@lock.lock("netools_data")
def clean_task_data(task_id):
    global task_data

    if task_id in task_data.keys():
        logger.info("clean task_data of task_id:%s" %str(task_id))
        del(task_data[task_id])

@lock.lock("netools_data")
def add_task_data(task_id, result):
    global task_data

    if not task_id in task_data.keys():
        task_data[task_id] = []

    dataresult = copy.deepcopy(result)
    logger.info("add task_data:%s in task_id:%s" %(str(result),str(task_id)))
    task_data[task_id].append(dataresult)

@lock.lock("netools_data")
def get_task_data(task_id):
    global task_data
    results = []

    if task_id in task_data.keys():
        results = task_data[task_id]
        logger.info("get task_data:%s of task_id:%s"%(str(results),str(task_id)))
        task_data[task_id] = []
        for result in results:
            if "complete" == result["result"]:
                logger.info("get task_data: result has all read out.")
                #del(task_data[task_id])
                complete_message = {}
                complete_message["guid"] = task_id
                complete_message["result"] = "complete"
                add_task_data(task_id, complete_message)

    return results

@AsyncThread
def netoolsHandler(netools_cmd, task_id):
    msg = {}
    popen = subprocess.Popen(netools_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, shell=True)
    line = popen.stdout.readline()

    while line != '':
        msg["guid"] = task_id
        msg["result"] = line.replace("\n", "")
        add_task_data(task_id, msg)

        line = popen.stdout.readline()

    msg["guid"] = task_id
    msg["result"] = "complete"
    add_task_data(task_id, msg)

    t = threading.Timer(30.0, clean_task_data, {task_id})
    logger.info("begin cleaning task_id:%s in 30 seconds." % str(task_id))
    t.start()

class NetoolPlugin(monitoragent.MonitorAgent):
    NETOOLS_PATH = "/netools/netools"
    RESULT_PATH = "/netools/results"

    @monitoragent.replyerror
    def get_result(self,req):
        global task_data

        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        task_id = cmd["guid"]

        prefix = "["
        suffix = "]"
        if task_id in task_data.keys():
            task_results = get_task_data(task_id)

            return_result = ""
            return_result += prefix
            for i, task_result in enumerate(task_results):
                task_suffix = ",\n"

                if i == len(task_results) - 1:
                    return_tmp = jsonobject.dumps(task_result)
                else:
                    return_tmp = jsonobject.dumps(task_result) + task_suffix

                return_result += return_tmp

            return_result += suffix
            return return_result
        else:
            returnobject = {}
            returnobject["guid"] = task_id
            returnobject["result"] = "there is no data in this task id"

            return prefix + jsonobject.dumps(returnobject) + suffix

    @monitoragent.replyerror
    def netools(self, req):
        returnobject = {}
        cmd = jsonobject.loads(req[http.REQUEST_BODY])

        command = cmd["command"]
        publish_ip = cmd["remote_ip"]
        task_id = cmd["guid"]

        netools_cmd = network_command(command, publish_ip)
        logger.info("netools generate command is:%s" % str(netools_cmd))

        if netools_cmd is None:
            returnobject["success"] = False
            returnobject["msg"] = "json is invalid"
        else:
            returnobject["success"] = True
            returnobject["msg"] = "success"
            netoolsHandler(netools_cmd, task_id)

        return jsonobject.dumps(returnobject)

    def start(self):
        http_server = monitoragent.get_http_server()
        http_server.register_sync_uri(self.NETOOLS_PATH, self.netools)
        http_server.register_sync_uri(self.RESULT_PATH, self.get_result)

    def stop(self):
        pass

    def configure(self, config):
        self.config = config
