'''
@author: frank
'''
from monitoragent import monitoragent
from syscxplib.utils import jsonobject
from syscxplib.utils import http
from syscxplib.utils import lock
from syscxplib.utils import log
from syscxplib.utils import shell
from syscxplib.utils import sizeunit
from syscxplib.utils import linux
from syscxplib.utils import thread
from syscxplib.utils.bash import *
from syscxplib.utils.report import Report
import os.path
import re
import threading
import time
class ConnectResponse(monitoragent.AgentResponse):
    def __init__(self):
        super(ConnectResponse, self).__init__()
        self.iptablesSucc = None
class HostFactResponse(monitoragent.AgentResponse):
    def __init__(self):
        super(HostFactResponse, self).__init__()
        self.hvmCpuFlag = None
class PingResponse(monitoragent.AgentResponse):
    def __init__(self):
        super(PingResponse, self).__init__()
        self.hostUuid = None
logger = log.get_logger(__name__)
def _get_memory(word):
    out = shell.ShellCmd("cat /proc/meminfo | grep '%s'" % word)()
    (name, capacity) = out.split(':')
    capacity = re.sub('[k|K][b|B]', '', capacity).strip()
    #capacity = capacity.rstrip('kB').rstrip('KB').rstrip('kb').strip()
    return sizeunit.KiloByte.toByte(long(capacity))
def _get_total_memory():
    return _get_memory('MemTotal')
def _get_free_memory():
    return _get_memory('MemFree')
def _get_used_memory():
    return _get_total_memory() - _get_free_memory()

class HostPlugin(monitoragent.MonitorAgent):
    '''
    classdocs
    '''
    CONNECT_PATH = '/host/connect'
    ECHO_PATH = '/host/echo'
    FACT_PATH = '/host/fact'
    PING_PATH = "/host/ping"
    @lock.file_lock('/run/xtables.lock')
    @in_bash
    def apply_iptables_rules(self, rules):
        logger.debug("starting add iptables rules : %s" % rules)
        if len(rules) != 0 and rules is not None:
            for item in rules:
                rule = item.strip("'").strip('"')
                clean_rule = ' '.join(rule.split(' ')[1:])
                ret = bash_r("iptables -C %s " % clean_rule)
                if ret == 0:
                    continue
                elif ret == 1:
                    # didn't find this rule
                    set_rules_ret = bash_r("iptables %s" % rule)
                    if set_rules_ret != 0:
                        raise Exception('cannot set iptables rule: %s' % rule)
                else:
                    raise Exception('check iptables rule: %s failed' % rule)
        return True
    @monitoragent.replyerror
    def connect(self, req):
        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        self.host_uuid = cmd.hostUuid
        self.config[monitoragent.HOST_UUID] = self.host_uuid
        self.config[monitoragent.SEND_COMMAND_URL] = cmd.sendCommandUrl
        Report.serverUuid = self.host_uuid
        Report.url = cmd.sendCommandUrl
        logger.debug(http.path_msg(self.CONNECT_PATH, 'host[uuid: %s] connected' % cmd.hostUuid))
        rsp = ConnectResponse()
        apply_iptables_result = self.apply_iptables_rules(cmd.iptablesRules)
        rsp.iptablesSucc = apply_iptables_result
        return jsonobject.dumps(rsp)

    @monitoragent.replyerror
    def ping(self, req):
        rsp = PingResponse()
        rsp.hostUuid = self.host_uuid
        return jsonobject.dumps(rsp)

    @monitoragent.replyerror
    def echo(self, req):
        logger.debug('get echoed')
        return ''
    @monitoragent.replyerror
    def fact(self, req):
        rsp = HostFactResponse()
        ipV4Addrs = shell.call("ip addr | grep -w inet | grep -v 127.0.0.1 | awk '{print $2}' | cut -d/ -f1")
        rsp.ipAddresses = ipV4Addrs.splitlines()
        cmd = shell.ShellCmd('cat /proc/cpuinfo | grep vmx')
        cmd(False)
        if cmd.return_code == 0:
            rsp.hvmCpuFlag = 'vmx'
        if not rsp.hvmCpuFlag:
            cmd = shell.ShellCmd('cat /proc/cpuinfo | grep svm')
            cmd(False)
            if cmd.return_code == 0:
                rsp.hvmCpuFlag = 'svm'
        return jsonobject.dumps(rsp)

    def start(self):
        self.host_uuid = None

        http_server = monitoragent.get_http_server()
        http_server.register_sync_uri(self.CONNECT_PATH, self.connect)
        http_server.register_async_uri(self.PING_PATH, self.ping)
        http_server.register_sync_uri(self.ECHO_PATH, self.echo)
        http_server.register_async_uri(self.FACT_PATH, self.fact)
    def stop(self):
        pass
    def configure(self, config):
        self.config = config