from monitoragent import monitoragent
from syscxplib.utils import jsonobject
from syscxplib.utils import http
from syscxplib.utils import log
from syscxplib.utils import lock
from syscxplib.utils.bash import *
from syscxplib.utils.thread import AsyncThread
import subprocess
import time
import re
import traceback
import copy
import threading

logger = log.get_logger(__name__)

# formatter:
# {
#     task_id:[result1,result2]
# }
task_data = {}
REPORT_INTERVAL = 2 #iperf3上报的时间间隔
failover_time = 7 #iperf server端容错时间

def _iperf_cmd(iperf_type, protocol_type, port, band_ip, dst_ip, bandwidth, duration_time, netns_name):
    command = None
    try:
        port = int(port)
    except ValueError, e:
        logger.info("parse variable of port failed")
        return None

    if "server" == iperf_type:
        command = "ip netns exec %s unbuffer iperf3 -s -1 -p %d -B %s -f b" % (netns_name, port, band_ip)
    elif "client" == iperf_type:
        try:
            duration_time = int(duration_time)
        except ValueError, e:
            logger.info("parse variable of duration_time failed")
            return None

        if "UDP" == protocol_type:
            try:
                bandwidth = int(bandwidth)
            except ValueError, e:
                logger.info("parse variable of bandwidth failed.")
                return None
            command = "ip netns exec %s unbuffer iperf3 -c %s -B %s -p %d -t %d -i %s -b %dM -u" \
                           % (netns_name, dst_ip, band_ip, port, duration_time, REPORT_INTERVAL, bandwidth)
        else:
            command = "ip netns exec %s unbuffer iperf3 -c %s -B %s -p %d -t %d -i %s" \
                      % (netns_name, dst_ip, band_ip, port, duration_time, REPORT_INTERVAL)

    return command

def _call_prog(cmd):
    popen = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, shell=True)
    return popen

def _rec(line):
    re_line = re.match(r'.*?Bytes  (\d+.\d+) bits/sec.*?', line)
    if re_line is None:
        re_line = re.match(r'.*?Bytes   (\d+.\d+) bits/sec.*?', line)

    if re_line:
        return re_line.group(1)

@lock.lock("iperf_data")
def clean_task_data(task_id):
    global task_data

    if task_id in task_data.keys():
        logger.info("clean task_data of task_id:%s" % str(task_id))
        del(task_data[task_id])

@lock.lock("iperf_data")
def add_task_data(task_id, result):
    global task_data

    if not task_id in task_data.keys():
        task_data[task_id] = []

    dataresult = copy.deepcopy(result)
    logger.info("add task_data:%s in task_id:%s" % (str(result), str(task_id)))
    task_data[task_id].append(dataresult)

@lock.lock("iperf_data")
def get_task_data(task_id):
    global task_data

    results = {}
    if task_id in task_data.keys():
        results = task_data[task_id]
        logger.info("get task_data:%s of task_id:%s" % (str(results), str(task_id)))
        task_data[task_id] = []
        for result in results:
            if True == result["complete_flag"]:
                logger.info("get task_data: result has all read out.delete task_id")
                #del(task_data[task_id])
                complete_message = {}
                complete_message["tunnel_id"] = result["tunnel_id"]
                complete_message["iperf_data"] = str(0.0)
                complete_message["complete_flag"] = True
                complete_message["time_stamp"] = str(time.time())
                complete_message["msg"] = "the task_id's data has been obtained"
                complete_message["success"] = False
                add_task_data(task_id,complete_message)

    return results

@AsyncThread
def iperfhandler(task_id, tunnel_id, iperf_type, duration_time, cmd):
    message = {}
    count = 0
    number = 0.00

    if "server" == iperf_type:
        popen = _call_prog(cmd)
        pid = popen.pid
        kill = "kill -9 %s" % pid
        line = popen.stdout.readline()
        endtime = time.time() + failover_time
        try:
            Interval_count = 0
            while line != '':
                if "sec" in line and "sender" not in line and "receiver" not in line:
                    endtime = time.time() + failover_time
                    if Interval_count >= 2:
                        avg_bandwidth = number / duration_time
                        message["tunnel_id"] = tunnel_id
                        message["iperf_data"] = str(avg_bandwidth)
                        message["complete_flag"] = True
                        message["time_stamp"] = str(time.time())
                        message["msg"] = "success"
                        message["success"] = True
                        time.sleep(REPORT_INTERVAL)
                        break
                    result = {}
                    re_bandwidth = _rec(line)
                    number = number + float(re_bandwidth)
                    result["tunnel_id"] = tunnel_id
                    result["iperf_data"] = str(re_bandwidth)
                    result["complete_flag"] = False
                    result["time_stamp"] = str(time.time())
                    result["msg"] = "success"
                    result["success"] = True

                    add_task_data(task_id, result)
                if ('sec' and 'receiver') in line:
                    endtime = time.time() + failover_time
                    avg_bandwidth = _rec(line)
                    message["tunnel_id"] = tunnel_id
                    message["iperf_data"] = str(avg_bandwidth)
                    message["complete_flag"] = True
                    message["time_stamp"] = str(time.time())
                    message["msg"] = "success"
                    message["success"] = True
                    time.sleep(REPORT_INTERVAL)
                if 'Interval' in line:
                    Interval_count += 1  # end_flag

                if int(time.time()) > endtime:
                    logger.info("Iperf server timeout!")
                    _call_prog(kill)
                    message["tunnel_id"] = tunnel_id
                    message["iperf_data"] = str(0.0)
                    message["complete_flag"] = True
                    message["time_stamp"] = str(time.time())
                    message["msg"] = "iperf server timeout"
                    message["success"] = False

                    # add_task_data(task_id, message)
                    break
                line = popen.stdout.readline()
            if message == {}:
                message["tunnel_id"] = tunnel_id
                message["iperf_data"] = str(0.0)
                message["complete_flag"] = True
                message["time_stamp"] = str(time.time())
                message["msg"] = "no result in server"
                message["success"] = False

            add_task_data(task_id, message)
            _call_prog(kill)
        except Exception, e:
            error_trace = traceback.format_exc()
            logger.error(error_trace)
            logger.error(e)
            _call_prog(kill)
            message["tunnel_id"] = tunnel_id
            message["iperf_data"] = str(0.0)
            message["complete_flag"] = True
            message["time_stamp"] = str(time.time())
            message["msg"] = "occured exception:" + str(e)
            message["success"] = "False"

            add_task_data(task_id, message)
    if "client" == iperf_type:
        while count < 3:
            try:
                popen = _call_prog(cmd)
                line = popen.stdout.readline()
                while line != "":
                    if "iperf3: error" in line and count < 3:
                        logger.info("Iperf client Error!")
                        count += 1
                        popen = _call_prog(cmd)
                    line = popen.stdout.readline()
                break
            except Exception as e:
                logger.error("error{}:{}".format(type(e), e))
                error_trace = traceback.format_exc()
                logger.error(error_trace)
                count += 1
                if count >= 3:
                    message["tunnel_id"] = tunnel_id
                    message["iperf_data"] = str(0.0)
                    message["complete_flag"] = True
                    message["time_stamp"] = str(time.time())
                    message["msg"] = "occured exception:" + str(e)
                    message["success"] = "False"

                    add_task_data(task_id, message)
    t = threading.Timer(30.0, clean_task_data, {task_id})
    logger.info("begin cleaning task_id:%s in 30 seconds." % str(task_id))
    t.start()

class IperfPlugin(monitoragent.MonitorAgent):
    IPERF_PATH = "/iperf/iperf"
    RESULT_PATH = "/iperf/results"

    @monitoragent.replyerror
    def get_result(self,req):
        global task_data

        cmd = jsonobject.loads(req[http.REQUEST_BODY])
        task_id = cmd["guid"]

        prefix = "["
        suffix = "]"
        if task_id in task_data.keys():
            task_results = get_task_data(task_id)

            return_result = ""
            return_result += prefix
            for i, task_result in enumerate(task_results):
                task_suffix = ",\n"

                if i == len(task_results) - 1:
                    return_tmp = jsonobject.dumps(task_result)
                else:
                    return_tmp = jsonobject.dumps(task_result) + task_suffix

                return_result += return_tmp

            return_result += suffix
            return return_result
        else:
            returnobject = {}
            returnobject["tunnel_id"] = ""
            returnobject["iperf_data"] = str(0.0)
            returnobject["complete_flag"] = True
            returnobject["time_stamp"] = str(time.time())
            returnobject["msg"] = "there is no data in this task id"
            returnobject["success"] = False

            return prefix + jsonobject.dumps(returnobject) + suffix

    @monitoragent.replyerror
    def iperf(self, req):
        returnobject = {}
        cmd = jsonobject.loads(req[http.REQUEST_BODY])

        task_id = cmd["guid"]
        tunnel_id = cmd["tunnel_id"]
        interface_name = cmd["interface_name"]
        vlan_id = cmd["vlan"]
        iperf_type = cmd["type"]
        protocol_type = cmd["protocol"]
        port = cmd["port"]
        band_ip = cmd["src_ip"]
        bandwidth = cmd["bandwidth"]
        duration_time = cmd["time"]
        dst_ip = cmd["dst_ip"]

        netns_name = interface_name + "_" + str(vlan_id)

        cmd = _iperf_cmd(iperf_type, protocol_type, port, band_ip, dst_ip, bandwidth, duration_time, netns_name)
        logger.info("iperf generate command is:%s" % str(cmd))

        if cmd is None:
            returnobject["success"] = False
            returnobject["msg"] = "json is invalid"
        else:
            returnobject["success"] = True
            returnobject["msg"] = "success"
            iperfhandler(task_id, tunnel_id, iperf_type, duration_time, cmd)

        return jsonobject.dumps(returnobject)

    def start(self):
        http_server = monitoragent.get_http_server()
        http_server.register_sync_uri(self.IPERF_PATH, self.iperf)
        http_server.register_sync_uri(self.RESULT_PATH, self.get_result)

    def stop(self):
        pass

    def configure(self, config):
        self.config = config
