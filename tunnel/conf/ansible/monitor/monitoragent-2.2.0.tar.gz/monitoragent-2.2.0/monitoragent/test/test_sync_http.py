'''

@author: frank
'''
from monitoragent import monitoragent
from syscxplib.utils import uuidhelper
from syscxplib.utils import log

logger = log.get_logger(__name__)


class ConnectCmd(monitoragent.AgentCommand):
    def __init__(self):
        self.hostUuid = uuidhelper.uuid()


class HostFactCmd(monitoragent.AgentCommand): pass


if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    service = monitoragent.new_rest_service()
    service.start()
