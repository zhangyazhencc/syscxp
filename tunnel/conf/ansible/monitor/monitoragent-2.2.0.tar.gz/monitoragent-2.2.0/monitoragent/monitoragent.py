'''

@author: frank
'''
from syscxplib.utils import plugin
from syscxplib.utils import http
from syscxplib.utils import log
from syscxplib.utils import jsonobject
from syscxplib.utils import daemon
from plugins.icmp_service import set_interface_init
import os.path
import traceback
import pprint
import functools
import os

logger = log.get_logger(__name__)
SEND_COMMAND_URL = 'SEND_COMMAND_URL'
HOST_UUID = 'HOST_UUID'
_rest_service = None


class MonitorError(Exception):
    '''kvm error'''


class MonitorAgent(plugin.Plugin):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        pass


def new_rest_service(config={}):
    global _rest_service
    if not _rest_service:
        _rest_service = MonitorRESTService(config)
    return _rest_service


def get_http_server():
    return _rest_service.http_server


class MonitorRESTService(object):
    http_server = http.HttpServer(port=7079)
    http_server.logfile_path = log.get_logfile_path()

    NO_DAEMON = 'no_deamon'
    PLUGIN_PATH = 'plugin_path'
    WORKSPACE = 'workspace'

    def __init__(self, config={}):
        self.config = config
        plugin_path = self._get_config(self.PLUGIN_PATH)
        if not plugin_path:
            plugin_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'plugins')
        self.plugin_path = plugin_path
        self.plugin_rgty = plugin.PluginRegistry(self.plugin_path)

    def _get_config(self, name):
        return None if not self.config.has_key(name) else self.config[name]

    def start(self, in_thread=True):
        _interface_init = set_interface_init()
        if _interface_init:
            _interface_init.start()
        config = {}
        self.plugin_rgty.configure_plugins(config)
        self.plugin_rgty.start_plugins()
        if in_thread:
            self.http_server.start_in_thread()
        else:
            self.http_server.start()

    def stop(self):
        self.plugin_rgty.stop_plugins()
        self.http_server.stop()


class AgentResponse(object):
    def __init__(self, success=True, error=None):
        self.success = success
        self.error = error if error else ''


class AgentCommand(object):
    def __init__(self):
        pass


def _build_url_for_test(paths):
    builder = http.UriBuilder('http://localhost:7079')
    for p in paths:
        builder.add_path(p)
    return builder.build()


def replyerror(func):
    @functools.wraps(func)
    def wrap(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            content = traceback.format_exc()
            err = '%s\n%s\nargs:%s' % (str(e), content, pprint.pformat([args, kwargs]))
            rsp = AgentResponse()
            rsp.success = False
            rsp.error = str(e)
            logger.warn(err)
            return jsonobject.dumps(rsp)

    return wrap


class MonitorDaemon(daemon.Daemon):
    def __init__(self, pidfile, config={}):
        super(MonitorDaemon, self).__init__(pidfile)

    def run(self):
        self.agent = new_rest_service()
        self.agent.start(in_thread=False)

